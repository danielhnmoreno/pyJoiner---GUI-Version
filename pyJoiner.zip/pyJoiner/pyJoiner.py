from tkinter import *
from tkinter import filedialog, messagebox
from functools import partial
import os

class Application:
    def __init__(self, master=None):

        self.button1 = Button(root, text = "File 1")
        self.button1.place(x=10,y=10)
        
        self.label1 = Label(root, text='File1 not loaded')
        self.label1.place(x=60,y=10)
        self.label1.number = '1'

        self.button1['command'] = partial(self.load_file, self.button1, self.label1)

        self.button2 = Button(root, text = "File 2")
        self.button2.place(x=10,y=50)
        
        self.label2 = Label(root, text='File2 not loaded')
        self.label2.place(x=60,y=50)
        self.label2.number = '2'

        self.button2['command'] = partial(self.load_file, self.button2, self.label2)

        self.buttonJoin = Button(root, text = "Join", font=('TkDefaultFont', '11'), command=self.join)
        self.buttonJoin.place(x=200, y=15, width=100, height=60)

    def load_file(self, button, label):
        button.file_loaded = filedialog.askopenfilename(filetypes = (("Exe Files", "*.exe"),("All files", "*.*") ))
        button.extension = os.path.splitext(button.file_loaded)[1]
        if button.file_loaded == '':
            label['text'] = 'File%s not loaded' %label.number
        else:
            label['text'] = os.path.basename(button.file_loaded)


    def join(self):        
        if self.label1['text'] == 'File1 not loaded' or self.label2['text'] == 'File2 not loaded':
            if self.label1['text'] == 'File1 not loaded':
                messagebox.showerror('Error','File1 not loaded')
            if self.label2['text'] == 'File2 not loaded':
                messagebox.showerror('Error','File2 not loaded')
        else:
            with open(self.button1.file_loaded, 'rb') as file1:
                with open(self.button2.file_loaded, 'rb') as file2:
                    with open('py_file.pyw', 'w') as py_file:
                        py_file.write('''import os

def join(file,file_name, file_extension):

    if not os.path.exists(os.environ["TEMP"]+os.sep+file_name+file_extension):
        with open(os.environ["TEMP"]+os.sep+file_name+file_extension,"wb") as output_file:
            output_file.write(file)
    os.startfile(os.environ["TEMP"]+os.sep+file_name+file_extension)

file1 = %s
file2 = %s

join(file1, "output_file1", "%s")
join(file2, "output_file2", "%s") ''' %( str(file1.read()), str(file2.read()), self.button1.extension, self.button2.extension))

            os.system('pyinstaller'
                            ' --distpath {0}'
                            ' --workpath {0}'
                            ' --specpath {0}'
                            ' --icon icon.ico --windowed --onefile {1}'\
                        .format(os.getcwd()+os.sep+'output',os.getcwd()+os.sep+'py_file.pyw'))

            messagebox.showinfo('Info','Done!')

root = Tk()
root.title('pyJoiner, by Daniel Moreno')
root.geometry('320x90')
root.iconbitmap('mushroom.ico')
root.resizable('False', 'False')
Application(root)
root.mainloop()



